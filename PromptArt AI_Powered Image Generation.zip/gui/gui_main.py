import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
import torch
from diffusers import StableDiffusionPipeline

class ImageGeneratorApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Image Generator")

        self.prompt_label = ttk.Label(self.root, text="Enter Prompt:")
        self.prompt_label.pack()

        self.prompt_entry = ttk.Entry(self.root)
        self.prompt_entry.pack()

        self.generate_button = ttk.Button(self.root, text="Generate Image", command=self.generate_image)
        self.generate_button.pack()

        # Create a placeholder for the displayed image
        self.image_label = ttk.Label(self.root)
        self.image_label.pack()

    def generate_image(self):
        prompt = self.prompt_entry.get()
        image = self.generate_image_from_prompt(prompt)
        self.display_image(image)

    def generate_image_from_prompt(self, prompt):
        model_id = "stabilityai/stable-diffusion-2"
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        image_gen_model = StableDiffusionPipeline.from_pretrained(model_id)
        image_gen_model = image_gen_model.to(device)
        image = image_gen_model(prompt, num_inference_steps=35).images[0]
        return image

    def display_image(self, image):
        # Resize the image to fit the GUI window
        image = image.resize((400, 400))
        # Convert the PIL image to a Tkinter-compatible format
        tk_image = ImageTk.PhotoImage(image=image)
        # Set the image to the label
        self.image_label.configure(image=tk_image)
        # Keep a reference to the image to prevent it from being garbage collected
        self.image_label.image = tk_image

    def run(self):
        self.root.mainloop()

def main():
    app = ImageGeneratorApp()
    app.run()

if __name__ == "__main__":
    main()
